from .config import Settings


settings = Settings()