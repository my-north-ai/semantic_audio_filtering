# TTS-data-augmentation
Synthetic data augmentation technique via LLM for audio. To serve as input for a TTS model training
![Explanation](/readmeImage.jpeg)
